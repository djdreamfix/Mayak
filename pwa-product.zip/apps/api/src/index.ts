import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';
import webpush from 'web-push';
import type { Mark, Color } from '@pwa/types';

/**
 * Backend API for the map marker PWA.
 *
 * This server exposes REST endpoints for creating markers and subscribing to
 * push notifications, and uses Socket.IO to broadcast marker lifecycle events
 * (creation and expiration) in real time.  Markers are kept in memory and
 * automatically removed after a fixed TTL.  The TTL value and VAPID keys can
 * be configured via environment variables.
 */

const app = express();
const httpServer = createServer(app);
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*'
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for markers and timers.  Each marker entry stores the
// marker itself and a timeout that will remove it when it expires.  In a
// production deployment you would persist markers in Redis with an expiry
// (EXPIRE) so that removal happens even if the process crashes.  The Upstash
// documentation notes that `EXPIRE` sets a timeout on a key and the key will
// automatically be deleted when it expires【130187837087025†L124-L156】.
const marks: Map<string, { mark: Mark; timeout: NodeJS.Timeout }> = new Map();

// List of push subscriptions.  In production you should store these in a
// database or Redis so they survive restarts.  Each subscription follows the
// standard Web Push specification.
const subscriptions: any[] = [];

// Time‑to‑live for markers in milliseconds (default 30 minutes).
const TTL_MS = parseInt(process.env.MARK_TTL_MS || '', 10) || 30 * 60 * 1000;

// VAPID keys for Web Push.  Generate your own pair via web-push generate-vapid-keys
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || '';
const WEB_PUSH_SUBJECT = process.env.WEB_PUSH_SUBJECT || 'mailto:example@example.com';

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(WEB_PUSH_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
}

/**
 * Remove a marker by id and broadcast the expiration to all clients.
 */
function removeMark(id: string) {
  const entry = marks.get(id);
  if (!entry) return;
  clearTimeout(entry.timeout);
  marks.delete(id);
  io.emit('mark.expired', id);
}

/**
 * Schedule expiry for a given marker.  If the expiry is in the past, the
 * marker is removed immediately.
 */
function scheduleExpiry(id: string, expiresAtISO: string) {
  const entry = marks.get(id);
  if (!entry) return;
  const expiresAt = new Date(expiresAtISO).getTime();
  const now = Date.now();
  const delay = expiresAt - now;
  if (delay <= 0) {
    removeMark(id);
    return;
  }
  entry.timeout = setTimeout(() => removeMark(id), delay);
}

/**
 * Create a new marker.  Validates input, generates an id and expiry, stores
 * the marker and its expiration timer, broadcasts to clients and triggers
 * push notifications.
 */
app.post('/marks', (req, res) => {
  const { lat, lng, color } = req.body;
  // Basic validation
  if (typeof lat !== 'number' || typeof lng !== 'number' || !['blue', 'green', 'split'].includes(color)) {
    return res.status(400).json({ error: 'Invalid payload' });
  }
  const id = uuidv4();
  const createdAt = new Date().toISOString();
  const expiresAt = new Date(Date.now() + TTL_MS).toISOString();
  const mark: Mark = { id, lat, lng, color: color as Color, createdAt, expiresAt };
  // Schedule removal
  const timeout = setTimeout(() => removeMark(id), TTL_MS);
  marks.set(id, { mark, timeout });
  // Broadcast to connected clients
  io.emit('mark.created', mark);
  // Send push notification to subscribers
  const titleMap: Record<Color, string> = { blue: 'Синя мітка', green: 'Зелена мітка', split: 'Синьо‑зелена мітка' };
  const payload = {
    title: 'Нова мітка',
    body: `${titleMap[mark.color]} на мапі`,
    icon: `/icons/${mark.color}.png`,
    data: { lat: mark.lat, lng: mark.lng }
  };
  for (const sub of subscriptions) {
    webpush.sendNotification(sub, JSON.stringify(payload)).catch(err => {
      console.error('Error sending push notification', err);
    });
  }
  res.json(mark);
});

/**
 * Return all active markers.  Clients use this endpoint when loading to get a
 * snapshot of the current state.
 */
app.get('/marks', (_req, res) => {
  const active = Array.from(marks.values()).map(entry => entry.mark);
  res.json(active);
});

/**
 * Register a push subscription.  The client should POST the subscription
 * object returned from PushManager.subscribe().
 */
app.post('/subscribe', (req, res) => {
  const subscription = req.body;
  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: 'Invalid subscription' });
  }
  subscriptions.push(subscription);
  res.json({ success: true });
});

/**
 * When a client connects via WebSocket, immediately send the snapshot of
 * current markers so the client is up to date.  Clients do not send any
 * messages over the socket; all creation happens via HTTP POST /marks.
 */
io.on('connection', socket => {
  const snapshot = Array.from(marks.values()).map(entry => entry.mark);
  socket.emit('marks.snapshot', snapshot);
});

// Start the server
const port = process.env.PORT || 3001;
httpServer.listen(port, () => {
  console.log(`API server listening on port ${port}`);
});