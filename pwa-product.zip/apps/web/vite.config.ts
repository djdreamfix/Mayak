import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the PWA front‑end.  This file configures the React
// plugin and optionally proxies API requests during development.  When the
// application is built for production the API base URL should be provided via
// the VITE_API_URL environment variable.

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        // Proxy API requests in development.  The VITE_API_URL variable should
        // include scheme and host (e.g. http://localhost:3001).
        '/api': {
          target: env.VITE_API_URL || 'http://localhost:3001',
          changeOrigin: true,
          rewrite: path => path.replace(/^\/api/, '')
        }
      }
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true
    }
  };
});