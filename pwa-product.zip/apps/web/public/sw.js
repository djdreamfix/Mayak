// Simple service worker for the map marker PWA.
//
// It pre‑caches the application shell and serves it offline.  It also listens
// for push events to display notifications when new markers are created and
// handles notification clicks to focus or open the app and send a message
// containing the marker coordinates.

const CACHE_NAME = 'pwa-marker-cache-v1';
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_ASSETS))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', event => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      return (
        cached ||
        fetch(event.request).catch(() => caches.match('/') || caches.match('/index.html'))
      );
    })
  );
});

// Display push notifications when the server sends them.  The payload is
// expected to be JSON with title, body, icon and data fields.
self.addEventListener('push', event => {
  const defaultData = { title: 'Нова мітка', body: 'На мапі з’явилась нова мітка' };
  let data = defaultData;
  if (event.data) {
    try {
      data = event.data.json();
    } catch (err) {
      // ignore parse errors
      console.warn('Push event data is not JSON', err);
    }
  }
  const title = data.title;
  const options = {
    body: data.body,
    icon: data.icon || '/icons/icon-192x192.png',
    data: data.data || {}
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// When the notification is clicked, focus an existing client or open a new
// window.  Pass the coordinates back to the client via postMessage so that
// the map can be centered on the marker.
self.addEventListener('notificationclick', event => {
  const data = event.notification.data || {};
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({ type: 'center', lat: data.lat, lng: data.lng });
          return client.focus();
        }
      }
      // No open window, open a new one with query parameters
      const url = data.lat && data.lng ? `/?lat=${data.lat}&lng=${data.lng}` : '/';
      return self.clients.openWindow(url);
    })
  );
});