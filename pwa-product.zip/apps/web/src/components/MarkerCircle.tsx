import React, { useEffect, useState, useMemo } from 'react';
import { Marker } from 'react-leaflet';
import L from 'leaflet';
import type { Mark } from '@pwa/types';

interface Props {
  mark: Mark;
}

/**
 * MarkerCircle renders a marker with a coloured circular background and a
 * countdown of the remaining minutes until it expires.  The countdown
 * recomputes every second.  The colour corresponds to the marker's colour
 * property (blue, green or split).  The CSS classes defined in index.css
 * determine the visual appearance.
 */
const MarkerCircle: React.FC<Props> = ({ mark }) => {
  const [minutesLeft, setMinutesLeft] = useState(() => calculateMinutesLeft());

  // Update the remaining minutes every second
  useEffect(() => {
    const interval = setInterval(() => {
      setMinutesLeft(calculateMinutesLeft());
    }, 1000);
    return () => clearInterval(interval);
  }, [mark.expiresAt]);

  // Calculate the remaining minutes until expiry
  function calculateMinutesLeft(): number {
    const remaining = new Date(mark.expiresAt).getTime() - Date.now();
    return Math.max(0, Math.ceil(remaining / 60000));
  }

  // Generate a Leaflet divIcon containing the countdown.  useMemo avoids
  // unnecessary re‑creation of the icon between renders when dependencies
  // haven't changed.
  const icon = useMemo(() => {
    return L.divIcon({
      className: '',
      html: `<div class="marker-circle ${mark.color}">${minutesLeft}</div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });
  }, [mark.color, minutesLeft]);

  return <Marker position={[mark.lat, mark.lng]} icon={icon} />;
};

export default MarkerCircle;