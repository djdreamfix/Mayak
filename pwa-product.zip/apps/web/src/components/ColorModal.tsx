import React from 'react';
import type { Color } from '@pwa/types';

interface Props {
  /** Called when the user chooses a colour. */
  onSelect: (color: Color) => void;
  /** Called when the user cancels the dialog. */
  onCancel: () => void;
}

/**
 * Colour selection modal.
 *
 * When a user clicks on the map to create a new marker this modal appears
 * offering three large buttons for the available colours: blue, green and
 * split (50/50 blue/green).  Selecting a button invokes onSelect with the
 * corresponding colour.  Clicking outside or pressing Escape should be
 * handled by the parent component by closing the modal (onCancel).
 */
const ColorModal: React.FC<Props> = ({ onSelect, onCancel }) => {
  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <button className="color-button blue" onClick={() => onSelect('blue')}>
          Синій
        </button>
        <button className="color-button green" onClick={() => onSelect('green')}>
          Зелений
        </button>
        <button className="color-button split" onClick={() => onSelect('split')}>
          50/50
        </button>
      </div>
    </div>
  );
};

export default ColorModal;