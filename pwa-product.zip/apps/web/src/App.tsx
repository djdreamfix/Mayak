import React, { useState, useEffect, useCallback } from 'react';
import { MapContainer, TileLayer, useMapEvents } from 'react-leaflet';
import { io, Socket } from 'socket.io-client';
import type { Mark, Color } from '@pwa/types';
import ColorModal from './components/ColorModal';
import MarkerCircle from './components/MarkerCircle';
// Import Leaflet styles (Vite will handle this) but also ensure CSS from
// node_modules/leaflet is available; the link tag in index.html covers it.

/**
 * Hook component to handle map click events.  When the user clicks on the map
 * the provided onClick callback is fired.  This component has no visual
 * representation and is used exclusively for side effects.
 */
const MapClickHandler: React.FC<{ onClick: (e: any) => void }> = ({ onClick }) => {
  useMapEvents({
    click: onClick
  });
  return null;
};

/**
 * Convert a base64 URL string to a Uint8Array.  This helper is required when
 * subscribing to push notifications with an application server key.
 */
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

const App: React.FC = () => {
  const [center, setCenter] = useState<[number, number] | null>(null);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [clickedPos, setClickedPos] = useState<[number, number] | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  // Acquire the user's geolocation on first render.  If the position cannot be
  // obtained fall back to a default location (Vinnytsia) so the map isn't
  // centered somewhere unexpected.
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => {
          setCenter([pos.coords.latitude, pos.coords.longitude]);
        },
        () => {
          // Default to Vinnytsia coordinates
          setCenter([49.233, 28.467]);
        }
      );
    } else {
      setCenter([49.233, 28.467]);
    }
  }, []);

  // Adjust map center if URL parameters provide lat/lng (used when clicking a push notification)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const lat = parseFloat(params.get('lat') || '');
    const lng = parseFloat(params.get('lng') || '');
    if (!isNaN(lat) && !isNaN(lng)) {
      setCenter([lat, lng]);
    }
  }, []);

  // Establish a WebSocket connection to receive real‑time marker updates
  useEffect(() => {
    const base = import.meta.env.VITE_SOCKET_URL || import.meta.env.VITE_API_URL || 'http://localhost:3001';
    const s = io(base, { path: '/socket.io' });
    setSocket(s);
    s.on('marks.snapshot', (snapshot: Mark[]) => {
      setMarks(snapshot);
    });
    s.on('mark.created', (mark: Mark) => {
      setMarks(prev => [...prev, mark]);
    });
    s.on('mark.expired', (id: string) => {
      setMarks(prev => prev.filter(m => m.id !== id));
    });
    return () => {
      s.disconnect();
    };
  }, []);

  // Subscribe to push notifications when the service worker is ready and the
  // user grants permission.  This effect runs once on mount.
  useEffect(() => {
    async function subscribePush() {
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') return;
      const registration = await navigator.serviceWorker.ready;
      const vapid = import.meta.env.VITE_VAPID_PUBLIC_KEY;
      const options: PushSubscriptionOptionsInit = {
        userVisibleOnly: true,
        applicationServerKey: vapid ? urlBase64ToUint8Array(vapid) : undefined
      };
      try {
        const subscription = await registration.pushManager.subscribe(options);
        await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(subscription)
        });
      } catch (err) {
        console.error('Failed to subscribe to push notifications', err);
      }
    }
    subscribePush().catch(console.error);
  }, []);

  // Listen for messages from the service worker (e.g. when a push notification
  // is clicked).  The worker sends a message with type="center" and lat/lng
  // fields; centre the map accordingly.
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      const handler = (event: MessageEvent) => {
        const { type, lat, lng } = event.data || {};
        if (type === 'center' && typeof lat === 'number' && typeof lng === 'number') {
          setCenter([lat, lng]);
        }
      };
      navigator.serviceWorker.addEventListener('message', handler);
      return () => {
        navigator.serviceWorker.removeEventListener('message', handler);
      };
    }
  }, []);

  // Handler for map clicks.  Stores the clicked position and opens the colour picker modal.
  const handleMapClick = useCallback((e: any) => {
    const { latlng } = e;
    setClickedPos([latlng.lat, latlng.lng]);
    setShowModal(true);
  }, []);

  // Create a marker by sending a POST to the API.  After creation the server
  // broadcasts the new marker via WebSocket so the local list will update.
  const createMarker = async (color: Color) => {
    if (!clickedPos) return;
    const [lat, lng] = clickedPos;
    try {
      await fetch('/api/marks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng, color })
      });
    } catch (err) {
      console.error('Failed to create marker', err);
    }
    setClickedPos(null);
    setShowModal(false);
  };

  return (
    <div style={{ height: '100%', width: '100%' }}>
      {center && (
        <MapContainer center={center} zoom={15} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
            url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          />
          <MapClickHandler onClick={handleMapClick} />
          {marks.map(mark => (
            <MarkerCircle key={mark.id} mark={mark} />
          ))}
        </MapContainer>
      )}
      {showModal && (
        <ColorModal
          onSelect={createMarker}
          onCancel={() => {
            setShowModal(false);
            setClickedPos(null);
          }}
        />
      )}
    </div>
  );
};

export default App;