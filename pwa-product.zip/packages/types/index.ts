// Shared TypeScript types for the map marker PWA

export type Color = 'blue' | 'green' | 'split';

/**
 * Representation of a map marker ("мітка").
 *
 * A marker is created when a user clicks on the map and chooses a colour.  It
 * contains the geographic location, the chosen colour, the timestamp of
 * creation and the timestamp when the marker should expire.  The id field is
 * a UUID assigned by the backend.  All timestamps are ISO‑8601 strings in
 * UTC.
 */
export interface Mark {
  id: string;
  lat: number;
  lng: number;
  color: Color;
  createdAt: string;
  expiresAt: string;
}